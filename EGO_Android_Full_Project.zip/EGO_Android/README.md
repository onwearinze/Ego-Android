# EGO — Early Growth & Opportunities
## Offline-first Android learning app for ages 1–5

EGO is designed to run without an internet connection. The app's HTML, learning content, games, illustrations (emoji/system glyphs), and interface are bundled in `app/src/main/assets/index.html` and loaded from the Android app's local assets.

### Offline and privacy design
- The Android manifest deliberately contains **no `INTERNET` permission**.
- No remote APIs, websites, fonts, images, analytics, advertising SDKs, trackers, sign-in, cloud storage or external links are used.
- Learning progress and the optional child name are saved in local WebView storage on the device.
- The app does not request location, contacts, camera, microphone or storage permissions.
- Audio narration uses Android's built-in text-to-speech engine. To guarantee spoken narration while fully disconnected, a parent should install an English offline voice in Android Settings → Text-to-speech output before going offline. If no offline voice is installed, lessons and games still work visually and by touch, but speech may not be available.

### Expanded learning library included in this build
- Numbers **1–100**, with number names and a spoken count-through activity.
- **107 two-letter word entries** (extended English word-game/dictionary forms; not all are suitable as a first reading list).
- Exactly **50 three-letter words** and **100 four-letter words**.
- **50 original offline SVG colouring pages** with a finger-drawing colour canvas.
- **30 named colours**, a colour-matching game and a simple on-screen colour-mixing activity.
- **18 shape concepts**, including common 2D shapes and 3D solids.
- **50 everyday household object names**.

### Learning areas included
- Alphabet A–Z and introductory phonics
- Early vocabulary and picture-word recognition
- Counting 1–10, number words, patterns, colours and shapes
- Family, community helpers and the world around the child
- Plants, animals, weather, senses and simple science
- Body parts, hygiene, healthy habits and nutrition
- Emotions, friendship, kindness and sharing
- Everyday safety and basic life skills
- Music, rhythm, movement, art and creativity
- Memory, sorting, matching and counting games
- Nigerian foods, crops, languages, places, wildlife, culture and national symbols
- Original short stories and spoken rhymes
- Parent area with child profile, local progress summary and reset control

### Age stages
The home screen provides age bands 1–2, 3–4 and 5. Lesson quantity is adjusted by selected age band. Caregiver supervision and real-world play are essential, especially for toddlers.

### Build an installable APK
This environment has no Android SDK or Gradle installation, so an APK has **not** been compiled here.
1. Install Android Studio on a computer.
2. Open this `EGO_Android` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The test APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
6. For distribution, choose **Build → Generate Signed Bundle / APK → APK**, create and securely back up your own signing key, then build a signed release.

### Scope notes
- There is no finite universal set of “all colours”: this build includes 30 named colour examples and a simple RGB-based screen mixer. Screen-light mixing is not identical to mixing physical paint.
- The two-letter bank contains 105 extended dictionary/word-game entries, including uncommon forms. It is a recognition library, not a recommendation that toddlers memorise every entry.
- The 50 colouring pages are simple original vector line drawings, not scanned commercial colouring-book artwork.

### Important limitations before public launch
This is a comprehensive starter app package, not a complete substitute for preschool, childcare or professional curriculum. Lesson content should be reviewed by Nigerian early-childhood educators, speech/language specialists and child-safety reviewers. Nigerian greetings and cultural material are introductory and should be checked with fluent speakers and cultural advisers. The parent gate is a simple in-app arithmetic check, not secure authentication. The app does not yet implement server-based multi-device sync, managed screen-time enforcement, formal diagnostic assessments, downloadable curriculum updates or professional recorded narration. Do not rely on it as a safety, medical or developmental assessment tool.
