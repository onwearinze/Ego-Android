# EGO 2.0 — My Little Learning World

A standalone, offline-first Android learning app for early learners. EGO is personalised to greet the child as **Ego** by default; a parent can change the displayed name in the parent area.

## What is in EGO 2.0

- **Number Explorer:** numbers 0–100, number names, spoken number cards, tens-and-ones place-value cards, and introductory addition, subtraction, multiplication and sharing/division games.
- **Sound Blending:** 26 common two-letter English words used in ordinary writing (not word-game-only entries), 50 three-letter words, 100 four-letter words, spoken word cards, swipe navigation, onset/rime blending practice and syllable clapping cards.
- **Tracing Centre:** finger tracing for A–Z and 0–9.
- **Shape World:** 2D and 3D shape recognition.
- **Colour Adventure:** colour recognition and matching.
- **Wonderful World:** introductory animals, nature, home and Nigeria cards.
- **Little Artist:** 50 bundled SVG outline pictures with the drawing canvas directly over the picture, so children colour the actual picture.
- **Memory Master:** picture-pair memory game.
- **Pattern Detective:** repeating-pattern games.
- **Little Maths Shop:** count coins and choose the right amount.
- **Listen and Do:** spoken instruction and listening-choice activities.
- **Story Builder:** short picture-led stories with spoken narration.
- **My Little Classroom:** teacher-led lesson turns and participating classmates.

The interface uses animated cards, child-friendly colours, swipeable word cards, spoken prompts, stars, local progress tracking, and short stretch reminders after repeated successful turns.

## Audio behaviour

- Spoken instructions and word playback use Android's Text-to-Speech engine through a native Android bridge.
- The app selects an installed English voice that does not require a network connection. If the phone has no offline English voice installed, speech will be unavailable until a parent installs one under **Android Settings → Text-to-speech output → Preferred engine / Install voice data**.
- Background music and celebration chimes are synthesised locally by the app using the device's audio engine. The parent controls speech, music and effects separately.
- This build does not contain a set of professionally recorded character voice files. The spoken voice is the installed Android offline TTS voice.

## Offline and privacy

- The Android manifest has **no INTERNET permission**.
- All lesson content, interface code and 50 colouring illustrations are bundled inside the APK.
- No remote APIs, ads, trackers, sign-in, analytics or cloud storage are used.
- Child name, stars and progress are stored locally in WebView storage on the device.
- No location, contacts, camera, microphone or storage permission is requested.
- The parent gate is a simple arithmetic check, not secure authentication.

## Build details

- Application ID: `com.ego.learning`
- Version: `2.0.0` (version code 3)
- Minimum Android: API 23
- Compile/target SDK: 35
- Gradle Android plugin: 8.7.3
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

A fixed debug keystore is included so cloud-generated debug builds of this project can update one another without a signature mismatch. It is for testing only. Do not use it for a public Play Store release; create and protect a separate private release key.

## Important scope note

EGO 2.0 is a substantial interactive preschool starter, not a clinical, speech-therapy or formal curriculum assessment product. The phonics sound cues are beginner prompts and should be reviewed by an early-years literacy specialist before formal educational distribution. Adult participation remains important, especially for children under three.
